package ru.lonelywh1te.kotlin_tasklist.domain.models

abstract class TaskItem